import logging

logger = logging.getLogger('asysocks.client.http')
logger.propagate = True