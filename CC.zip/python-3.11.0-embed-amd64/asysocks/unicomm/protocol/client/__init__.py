import logging

logger = logging.getLogger('asysocks.client')
logger.propagate = True