import logging

logger = logging.getLogger('asyauth.credssp')
logger.propagate = True