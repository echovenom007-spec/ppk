import logging

logger = logging.getLogger('asyauth.kerberos')
logger.propagate = True