import logging

logger = logging.getLogger('asyauth.ntlm')
logger.propagate = True